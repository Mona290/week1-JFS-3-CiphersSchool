package Test;
import java.util.Scanner;
public class Employee_Payroll {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the basic pay :");
		
		double basicPay = sc.nextInt();
		double HRA=0,DA=0;
		
		if(basicPay >= 5000) {
		     HRA = (10*basicPay)/100;
			 DA =  (20*basicPay)/100;
			 
			
		}
		else {
			HRA = (20*basicPay)/100;
			DA = (30*basicPay)/100;
			
			
		}
		System.out.println(HRA+" "+DA);
		
		System.out.println(basicPay+ HRA+DA);
		
		sc.close();
		
	}
	

}
