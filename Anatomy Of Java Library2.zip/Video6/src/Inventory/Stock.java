package Inventory;

public class Stock {
	public String iAmAccessubleEverywhere;
	
	private String iamAccessibleOnlyHere;
	
	protected String iAmAccessibletoDerivedClassess;
	
	String iAmAccessibleToAllClassInSamePacakage;

}
