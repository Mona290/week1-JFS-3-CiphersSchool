package Test;

public class whileLoop {
	public static void main(String[] args) {
		char ch ='A';
	
	while(ch < 90) {
		System.out.print(ch+" ");
		ch++;
	}
	//do while loop
	char cha ='A';
	do {
		System.out.print(ch +" ");
		cha++;
	}
	while(cha<='Z');
	

} 
	}
