package Inventory;

public class EncapStockP{
    public String iAmAccesibleEverywhere;
    private String iAmAccessibleOnlyHere;
    protected String IAmAccesibleToDerivedClasses;
    String iAmAccesibleToAllClassInSamePackage;
}